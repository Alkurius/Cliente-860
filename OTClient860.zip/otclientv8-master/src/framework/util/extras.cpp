#include "extras.h"
#include <numeric>
#include <algorithm>
#include <sstream>

Extras g_extras;
