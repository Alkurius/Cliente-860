# OTClientV8 partial sources (90% of code)

To help you understand how OTClientV8 works, some parts of source code has been published.
All files from client/ dir has been shared, but there few places with hidden code due to various reasons
In the future more parts of OTCv8 will be available here

If you want buy access to full sources, contact kondrah#7945 on discord
Or send mail to otclient@otclient.ovh (but discord is better)
